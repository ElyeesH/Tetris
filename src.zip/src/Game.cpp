#include"Game.hpp"
#include<random> 
#include<iostream>
#include<time.h>
#include"Clavier.hpp"
Game::Game()
{
	grid = Grid();
	blocks = GetAllBlocks();
	currentBlock = GetRandomBlock();
	nextBlock = GetRandomBlock();
	level = 1;
	BlockGiven = 2;
	Animated = false;
	gameOver = false;
	if (!musicGame.openFromFile("music.ogg"))
	{
		std::cout << "error" << std::endl;
	}

	if (!font.loadFromFile("Arial.ttf")) std::cout << "error to load ff file " << std::endl;

	musicGame.setVolume(50);
	musicGame.play();
	musicGame.setLoop(true);
	if (!buffer.loadFromFile("rotate.ogg")) {
		std::cout << "mnjmch nhell t3 rotate" << std::endl;
	}
	soundRotate.setBuffer(buffer);
	soundRotate.setVolume(200);
	//sf::SoundBuffer buffer1;
	if (!buffer1.loadFromFile("clear.ogg")) { std::cout << "mnjmch nhell t3 clear" << std::endl; }
	soundClear.setBuffer(buffer1);
	soundClear.setVolume(500);
	if (!DropBuffer.loadFromFile("drop.ogg")) { std::cout << "njmch nhell drop " << std::endl; }
	Drop.setBuffer(DropBuffer);

	Drop.setVolume(20);
}
std::vector<Block> Game::GetAllBlocks()
{

	return { IBlock(), JBlock(), LBlock(), OBlock(), TBlock(), ZBlock() };

}

Block Game::GetRandomBlock()
{
	if (blocks.empty())
	{
		blocks = GetAllBlocks();
	}
	int radomIndex = rand() % blocks.size();
	Block block = blocks[radomIndex];
	blocks.erase(blocks.begin() + radomIndex);
	UpdateLevel();
	BlockGiven++;
	return block;
}

void Game::MoveBlockleft()
{
	if (!gameOver) 
	{
		currentBlock.move(0, -1);
		if (IsBlookOutside() || !BlockFits()) MoveBlockRight();
	}
}

void Game::MoveBlockRight()
{
	if (!gameOver) {
		currentBlock.move(0, 1);
		if (IsBlookOutside() || !BlockFits()) currentBlock.move(0, -1);
	}
}
void Game::MoveBlockDown()
{
	if (!gameOver)
	{
		currentBlock.move(1, 0);
		if (IsBlookOutside() || !BlockFits())
		{
			currentBlock.move(-1, 0);
			Animated = true;
			if (ClockFit.getElapsedTime().asMilliseconds() > 2000)
			{
				LockBlock();
				Animated = false;
			}
		}
		else { ClockFit.restart(); }

	}
}
void Game::InstantDrop()
{
	if (!gameOver) {
		while (true)
		{
			currentBlock.move(1, 0);
			if (IsBlookOutside() || !BlockFits()) {

				currentBlock.move(-1, 0);
				LockBlock();
				Animated = false;
				break;
			}
		}
		Drop.play();
	}
}
void Game::chutelibre()
{
	if (level >= 9) { // level god 
		for (int row = 0; row < grid.numRows; row++)
		{
			MoveBlockDown();
		}
	}
	else
	{

		if (ClockChute.getElapsedTime().asMilliseconds() > GetClockChuteMicro())
			MoveBlockDown();
		ClockChute.restart();

	}
}


bool Game::IsBlookOutside()
{
	std::vector<Position> tiles = currentBlock.get_cell_postion();
	for (Position item : tiles)
	{
		if (grid.IsCellOutside(item.row, item.col)) return true;
	}
	return false;
}
void Game::RotateBlock(int i)
{
	if (!gameOver)
	{
		currentBlock.Rotate(i);
		if (IsBlookOutside() || !BlockFits())
		{
			currentBlock.Rotate(-1);
		}
		soundRotate.play();
	}
}


void Game::LockBlock() // pour figer le bloque 
{

	std::vector<Position> tiles = currentBlock.get_cell_postion();
	std::cout << tiles[0].row << std::endl;

	for (Position item : tiles)
	{
		grid.grid[item.row][item.col] = currentBlock.id;
	}
	currentBlock = nextBlock;
	if (!BlockFits())
	{
		gameOver = true;
	}
	nextBlock = GetRandomBlock();

	int rowsCleared = grid.ClearFullRows();

	if (rowsCleared > 0)
	{
		soundClear.play();

	}
	UpdateScore(rowsCleared, 0);
}


bool Game::BlockFits()
{
	std::vector<Position> tiles = currentBlock.get_cell_postion();
	for (Position item : tiles)
	{
		if (!grid.IsCellEmpty(item.row, item.col))
			return false;
	}
	return true;

}


/*void Game::LockBlock() // pour figer le bloque 
{
	std::vector<Position> tiles = currentBlock.get_cell_postion();

	for (Position item : tiles)
	{
		grid.grid[item.row][item.col] = currentBlock.id;
	}
	currentBlock = nextBlock;
	if (!BlockFits())
	{
		gameOver = true;
	}
	nextBlock = GetRandomBlock();
	int rowsCleared = grid.ClearFullRows();

	if (rowsCleared > 0)
	{
	soundClear.play();
	}
}*/


void Game::UpdateLevel()
{
	return;
}

void Game::UpdateScore(int LinesCleared, int moveDownPoints)
{
	switch (LinesCleared)
	{
	case 1:
		score += 100;
		break;
	case 2:
		score += 300;
		break;
	case 3:
		score += 500;
		break;
	default:
		break;

	}
	score += moveDownPoints;
}

void Game::HandleInput()
{
	if (gameOver && KeyboardManager::keyDown(sf::Keyboard::Enter))
	{
		gameOver = false;
		Reset();
	}
	if(KeyboardManager::keyDown(sf::Keyboard::Left))
	{
		MoveBlockleft();

	}
	if (KeyboardManager::keyDown((sf::Keyboard::Right)))
	{
		MoveBlockRight();
	}
	if (KeyboardManager::keyDown((sf::Keyboard::Down)))
	{
		MoveBlockDown();	
	}
	if (KeyboardManager::keyDown((sf::Keyboard::Space)))
	{
		InstantDrop();

	}
	if (KeyboardManager::keyDown((sf::Keyboard::Z)))
	{
		RotateBlock(1);
	}

	if (KeyboardManager::keyDown((sf::Keyboard::W)))
	{
		RotateBlock(-1);
	}
}

void Game::Reset()
{
	grid.initialiser();
	blocks = GetAllBlocks();
	currentBlock = GetRandomBlock();
	nextBlock = GetRandomBlock();
	score = 0;
	level = 1;
}
int Game::GetClockChuteMicro()
{
	return 100;
}





