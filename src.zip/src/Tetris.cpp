﻿#include "Tetris.hpp"
#include"colors.hpp"
#include"RoundedRectangleShape.hpp" 

void Tetris::drawText(sf::String content, int size, float x, float y, bool Gras = false)
{
    sf::Text text(content, font, size);
    text.setFillColor(sf::Color::White);
    text.setPosition(x, y);
    if (Gras) text.setStyle(sf::Text::Bold);
    render.draw(text);

}
void Tetris::drawRectangle(float length, float width, float x, float y)
{
    sf::RoundedRectangleShape rectangle(sf::Vector2f(length, width), 10, 10);
    rectangle.setPosition(x, y);
    rectangle.setFillColor(lightBlue);
    render.draw(rectangle);
}




void Tetris::draw()
{


    render.clear();

    sf::Texture BackgroundTexture;
    if (!BackgroundTexture.loadFromFile("assets/OIP.jpg")) std::cout << "no image " << std::endl;



    sf::Sprite background;
    sf::Vector2u TextureSize;  
    sf::Vector2u WindowSize;   
    TextureSize = BackgroundTexture.getSize();
    sf::Vector2u renderSize = render.getSize();
    float ScaleX = (float)renderSize.x / TextureSize.x;
    float ScaleY = (float)renderSize.y / TextureSize.y;     
    background.setTexture(BackgroundTexture);
    background.setScale(ScaleX, ScaleY);        
    background.setColor(sf::Color(255, 255, 255, 150));
    render.draw(background);

    drawRectangle(300, 100, 550, 70);
    drawRectangle(250, 180, 550, 300);
    drawRectangle(300, 100, 550, 600);
    drawText("Score", 40, 590, 5);
    drawText("Next", 40, 590, 250);
    drawText(std::to_string(score), 70, 590, 80, true);
    drawText("Level", 40, 600, 550);
    drawText(std::to_string(level), 70, 590, 630, true);
    if (gameOver)
    {
        drawText("Game Over ", 40, 700, 600);
        if (client != NULL) client->sendGameOver();

    }
    grid.draw(render, currentBlock.get_cell_postion());
    currentBlock.draw(render, 11, 11, Animated, clockAnimated);
    nextBlock.draw(render, 480, 325, false, clockAnimated);

    render.display();

}


void Tetris::drawUserWorlds()
{
    int cell_size = 35;
    int mini_cell_size = 20;
    int starty = 52;
    std::vector<sf::Color> colors = GetCellColors();


    int step = 0;
    int usr = -1;

    for (int n = 0; n < 2; n++) {

        int posy = step * mini_cell_size * 22 + step * 66;

        usr++;
        if (client->getId() == usr) {
            usr++;
        }



        step++;
        int** world = client->getUserWorld(usr);


        drawText(client->getName(usr), 40, 1000, posy, false);
        for (int x = 0; x < 22; x++) {
            for (int y = 0; y < 10; y++) {
                sf::RectangleShape rectangle1;
                int cell_value = world[x][y];

                sf::RectangleShape rectangle;
                rectangle1.setSize(sf::Vector2f(mini_cell_size - 1, mini_cell_size - 1));
                rectangle1.setPosition(y * mini_cell_size + 1000, posy + x * mini_cell_size + 50);
                rectangle1.setOutlineThickness(1);
                rectangle1.setOutlineColor(sf::Color::Cyan);

                rectangle1.setFillColor(colors[cell_value]);

                render.draw(rectangle1);
            }


        }
        

        
        int pieceID = client->getPieceID(usr);
        int* piece = client->getPiece(usr);

        for (int p = 0; p < 8; p += 2) {
            /*
            block.setColor(PIECE_COLOR[piece[p] - 1]);
            block.setPosition(posx + (p % 4 + piece_x) * tile, posy + (p / 4 + piece_y) * tile);
            render.draw(block);
            */
            sf::RectangleShape rectangle;
            rectangle.setSize(sf::Vector2f(mini_cell_size - 1, mini_cell_size - 1));
            rectangle.setPosition(piece[p + 1] * mini_cell_size + 1000, posy + piece[p] * mini_cell_size + 50);
            // colors[pieceID].a = 255;

            rectangle.setFillColor(colors[pieceID]);

            render.draw(rectangle);
        }

    }
    usr++;
    int** world = client->getUserWorld(usr);
    int posy = 300;
    int posx = 1000 + 22 * mini_cell_size;
    

 
    drawText(client->getName(usr), 40, posx, posy, false);
    for (int x = 0; x < 22; x++) {
        for (int y = 0; y < 10; y++) {
            sf::RectangleShape rectangle1;
            int cell_value = world[x][y];

            sf::RectangleShape rectangle;
            rectangle1.setSize(sf::Vector2f(mini_cell_size - 1, mini_cell_size - 1));
            rectangle1.setPosition(y * mini_cell_size + posx, posy + x * mini_cell_size +50);
            rectangle1.setOutlineThickness(1);
            rectangle1.setOutlineColor(sf::Color::Cyan);

            rectangle1.setFillColor(colors[cell_value]);

            render.draw(rectangle1);
        }


    }

    int pieceID = client->getPieceID(usr);
    int* piece = client->getPiece(usr);

    for (int p = 0; p < 8; p += 2) {


        sf::RectangleShape rectangle;
        rectangle.setSize(sf::Vector2f(mini_cell_size - 1, mini_cell_size - 1));
        rectangle.setPosition(piece[p + 1] * mini_cell_size + posx, posy + piece[p] * mini_cell_size + 50);

        rectangle.setFillColor(colors[pieceID]);

        render.draw(rectangle);
    }

    render.display();
}





